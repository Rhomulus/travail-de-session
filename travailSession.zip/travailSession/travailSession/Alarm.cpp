#include "Alarm.h"
#include <Arduino.h>
#include <HCSR04.h>
extern HCSR04 hc;

Alarm::Alarm(int rPin, int gPin, int bPin, int buzzerPin, float* distancePtr)
  : rPin(rPin), gPin(gPin), bPin(bPin), buzzerPin(buzzerPin), _distance(distancePtr) {
  pinMode(rPin, OUTPUT);
  pinMode(gPin, OUTPUT);
  pinMode(bPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  _turnOff();
}

void Alarm::update() {
  _currentTime = millis();
  *_distance = getDistance();
 
  switch (_state) {
    case OFF: _offState(); break;
    case WATCHING: _watchState(); break;
    case ON: _onState(); break;
    case TESTING: _testingState(); break;
  }
}

void Alarm::setColourA(int r, int g, int b) {
  _colA[0] = constrain(r, 0, 255);// constrain(255,0,0 )
  _colA[1] =constrain(g, 0, 255);
  _colA[2] = constrain(b, 0, 255);
}

void Alarm::setColourB(int r, int g, int b) {
  _colB[0] =constrain(r, 0, 255);
  _colB[1] = constrain(g, 0, 255);
  _colB[2] = constrain(b, 0, 255);
}

void Alarm::setVariationTiming(unsigned long ms) {
  _variationRate = ms;
}
void Alarm::setDistance(float d) {
  _distanceTrigger = d;
}
float Alarm::getDistance() {
  return hc.dist();
}

void Alarm::setTimeout(unsigned long ms) {
  _timeoutDelay = ms;
}

void Alarm::turnOff() {
  _turnOffFlag = true;
}
void Alarm::turnOn() {
  _turnOnFlag = true;
}
void Alarm::test() {
  _state = TESTING;
  _testStartTime = millis();
}
AlarmState Alarm::getState() const {
  return _state;
}

void Alarm::_setRGB(int r, int g, int b) {
  analogWrite(rPin, r);
  analogWrite(gPin, g);
  analogWrite(bPin, b);
}

void Alarm::_turnOff() {
  _setRGB(0, 0, 0);
  digitalWrite(buzzerPin, LOW);
}

void Alarm::_offState() {
  turnOn();
  if (_turnOnFlag) {
    _turnOnFlag = false;
    _state = WATCHING;
  }
}

void Alarm::_watchState() {
  if (_turnOffFlag) {
    _turnOffFlag = false;
    _state = OFF;
    _turnOff();
    return;
  }

  if (*_distance <= _distanceTrigger) {
    _state = ON;
    _lastDetectedTime = millis();
  }
}

void Alarm::_onState() {
  if (_turnOffFlag) {
    _turnOffFlag = false;
    _state = OFF;
    _turnOff();
    return;
  }

  if (_currentTime - _lastUpdate >= _variationRate) {
    _lastUpdate = _currentTime;
    _currentColor = !_currentColor;

    // Serial.println("ON");
    if (_currentColor) {
      _setRGB(_colA[0], _colA[1], _colA[2]);
    } else {
      _setRGB(_colB[0], _colB[1], _colB[2]);
    }

    digitalWrite(buzzerPin, HIGH);
  }

  if (*_distance > _distanceTrigger) {
    if (_currentTime - _lastDetectedTime >= _timeoutDelay) {
      _state = WATCHING;
      _turnOff();
    }
  } else {
    _lastDetectedTime = _currentTime;
  }
}


void Alarm::_testingState() {
  if (_currentTime - _lastUpdate >= _variationRate) {
    _lastUpdate = _currentTime;
    _currentColor = !_currentColor;

    if (_currentColor) {
      _setRGB(_colA[0], _colA[1], _colA[2]);
    } else {
      _setRGB(_colB[0], _colB[1], _colB[2]);
    }

    digitalWrite(buzzerPin, HIGH);
  }

  if (_currentTime - _testStartTime >= 2000) {
    _state = WATCHING;
    _turnOff();
  }
}
