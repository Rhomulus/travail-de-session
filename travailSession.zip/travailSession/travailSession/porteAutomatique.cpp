#include "PorteAutomatique.h"
#include <Arduino.h>
#include <WiFi.h>  
#include <AccelStepper.h>
#include <PubSubClient.h> 
extern void reconnectMQTT(); 

extern WiFiClient espClient;  
extern PubSubClient client;

const char* topicEtat = "porte/etat";
const char* topicAngle = "porte/angle";

//  PorteAutomatique 
PorteAutomatique::PorteAutomatique(int p1, int p2, int p3, int p4, float& distancePtr)
    : IN_1(p1), IN_2(p2), IN_3(p3), IN_4(p4), _distance(distancePtr),
      _stepper(AccelStepper::FULL4WIRE, p1, p3, p2, p4) { 

    _stepsPerRev = 2048;  
    _angleOuvert = 90.0;
    _angleFerme = 0.0;
    _distanceOuverture = 50.0;
    _distanceFermeture = 20.0;

    _stepper.setMaxSpeed(700);
    _stepper.setAcceleration(200);
    _stepper.setSpeed(300);
    _stepper.setCurrentPosition(_angleEnSteps(_angleFerme));

    _etat = FERMEE;
}

void PorteAutomatique::update() {
    _stepper.run();

    switch (_etat) {
        case FERMEE:
            if (_distance > _distanceOuverture) {
                _ouvrir();
                sendEtatMQTT(); 
            }
            break;
        case OUVERTE:
            if (_distance < _distanceFermeture) {
                _fermer();
                sendEtatMQTT();  
            }
            break;
        case EN_OUVERTURE:
            if (!_stepper.isRunning()) {
                _etat = OUVERTE;
                sendEtatMQTT();  
            }
            break;
        case EN_FERMETURE:
            if (!_stepper.isRunning()) {
                _etat = FERMEE;
                sendEtatMQTT();  // Envoi MQTT
            }
            break;
    }
}

// MQTT 

void PorteAutomatique::sendEtatMQTT() {
    if (!client.connected()) {
        Serial.println("MQTT non connecté, envoi annulé");
        return;
    }

    String message = "etatPorte:" + String(_etat);
    if (client.publish(topicEtat, message.c_str())) {
        Serial.println("Etat porte publié MQTT");
    } else {
        Serial.println("Erreur publication MQTT");
    }
}

void PorteAutomatique::setAngleOuvert(float angle) {
    _angleOuvert = constrain(angle, 0.0, 360.0);
}

void PorteAutomatique::setAngleFerme(float angle) {
    _angleFerme = constrain(angle, 0.0, 360.0);
}

void PorteAutomatique::setPasParTour(int steps) {
    _stepsPerRev = (steps > 0) ? steps : 2048;
}

void PorteAutomatique::setDistanceOuverture(float distance) {
    _distanceOuverture = (distance > 0) ? distance : 10.0;
}

void PorteAutomatique::setDistanceFermeture(float distance) {
    _distanceFermeture = (distance > 0) ? distance : 5.0;
}

const char* PorteAutomatique::getEtatTexte() const {
    switch (_etat) {
        case FERMEE: return "Fermee";
        case OUVERTE: return "Ouverte";
        case EN_OUVERTURE: return "En ouverture";
        case EN_FERMETURE: return "En fermeture";
        default: return "Inconnu";
    }
}

float PorteAutomatique::getAngle() const {
    return (_stepper.currentPosition() / (float)_stepsPerRev) * 360.0;
}

void PorteAutomatique::_ouvrir() {
    long targetSteps = _angleEnSteps(_angleOuvert);
    _stepper.moveTo(targetSteps);
    _etat = EN_OUVERTURE;
}

void PorteAutomatique::_fermer() {
    long targetSteps = _angleEnSteps(_angleFerme);
    _stepper.moveTo(targetSteps);
    _etat = EN_FERMETURE;
}

long PorteAutomatique::_angleEnSteps(float angle) const {
    return (long)((angle / 360.0) * _stepsPerRev);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {

}


